# CSS-only Rain Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexdevio/pen/poPyvYY](https://codepen.io/alexdevio/pen/poPyvYY).

Rain Effect done with HTML and CSS only.